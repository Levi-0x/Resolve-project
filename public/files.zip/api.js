// Shared by every page. Change API_BASE if the backend runs somewhere else.
const API_BASE = "http://localhost:3000";

const Session = {
  save({ accessToken, refreshToken, user }) {
    localStorage.setItem("accessToken", accessToken);
    localStorage.setItem("refreshToken", refreshToken);
    localStorage.setItem("user", JSON.stringify(user));
  },
  get token() {
    return localStorage.getItem("accessToken");
  },
  get user() {
    try {
      return JSON.parse(localStorage.getItem("user"));
    } catch {
      return null;
    }
  },
  clear() {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    localStorage.removeItem("user");
  },
};

// Returns the parsed JSON body. Throws an Error whose message is the server's
// "detail" text, so pages can show it directly.
async function apiRequest(path, { method = "GET", body, auth = false } = {}) {
  const headers = {};
  if (body) headers["Content-Type"] = "application/json";
  if (auth && Session.token) headers.Authorization = `Bearer ${Session.token}`;

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    if (window.location.protocol === "file:") {
      throw new Error("Open this page with Live Server (http://127.0.0.1:5500), not by double-clicking the file.");
    }
    throw new Error("Cannot reach the server. Check that the backend is running.");
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "Something went wrong");
  return data;
}
